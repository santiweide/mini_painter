package controller.operator;

public interface IOperator {
    void run();
}
