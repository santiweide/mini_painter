package model.interfaces;

/**
 * @author algorithm
 */
public interface IShapeListObserver {
    /**
     * 观察者更新状态
     */
    void update();
}
