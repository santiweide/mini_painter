package model.interfaces;

/**
 * @author algorithm
 */
public interface IMouseAdapterObserver {
    void run();
}
