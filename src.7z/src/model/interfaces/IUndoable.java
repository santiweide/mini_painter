package model.interfaces;

/**
 * @author algorithm
 */
public interface IUndoable {
    void undo();
    void redo();
}
