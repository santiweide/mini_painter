package view.interfaces.draw;

public interface ISelectable {
    void setIsSelected(boolean b);
    boolean getIsSelected();
}
